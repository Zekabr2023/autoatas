
import React from 'react';
import { MinutesTemplate } from '../types';

interface TranscriptionViewProps {
  transcription: string;
  onGenerate: () => void;
  onReset: () => void;
  error: string;
  minutesTemplate: MinutesTemplate;
  setMinutesTemplate: (template: MinutesTemplate) => void;
}

const TranscriptionView: React.FC<TranscriptionViewProps> = ({ transcription, onGenerate, onReset, error, minutesTemplate, setMinutesTemplate }) => {
  return (
    <div className="w-full bg-white/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 shadow-2xl backdrop-blur-sm animate-fade-in">
      <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-4">Transcrição da Reunião</h2>
      <div className="prose dark:prose-invert prose-slate max-w-none bg-slate-100 dark:bg-slate-900/50 rounded-lg p-4 h-96 overflow-y-auto border border-slate-200 dark:border-slate-700">
        {transcription.split('\n').map((line, index) => (
          <p key={index} className="my-2">{line}</p>
        ))}
      </div>
      
      <div className="mt-6">
        <label htmlFor="template-select" className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">
          Modelo da Ata
        </label>
        <select
          id="template-select"
          value={minutesTemplate}
          onChange={(e) => setMinutesTemplate(e.target.value as MinutesTemplate)}
          className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-3 text-slate-900 dark:text-slate-200 focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 outline-none transition-all"
        >
          <option value={MinutesTemplate.FORMAL}>Ata Formal Completa</option>
          <option value={MinutesTemplate.SUMMARY}>Resumo Executivo (Decisões e Ações)</option>
          <option value={MinutesTemplate.AGENDA}>Pauta com Deliberações</option>
        </select>
      </div>

      {error && <p className="text-red-500 dark:text-red-400 mt-4">{error}</p>}

      <div className="flex flex-col sm:flex-row gap-4 mt-6">
        <button
          onClick={onReset}
          className="interactive-button w-full sm:w-auto bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-200 font-bold py-3 px-6 rounded-lg transition-colors"
        >
          Começar de Novo
        </button>
        <button
          onClick={onGenerate}
          className="interactive-button flex-1 bg-cyan-500 hover:bg-cyan-600 text-slate-900 font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-[0_0_20px_rgba(56,189,248,0.3)]"
        >
          Gerar Ata da Reunião
        </button>
      </div>
    </div>
  );
};

export default TranscriptionView;