
import React from 'react';
import { SettingsIcon } from './icons/SettingsIcon';
import { HistoryIcon } from './icons/HistoryIcon';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';

interface HeaderProps {
    onSettingsClick: () => void;
    onHistoryClick: () => void;
    onThemeToggle: () => void;
    currentTheme: 'light' | 'dark';
}

const Header: React.FC<HeaderProps> = ({ onSettingsClick, onHistoryClick, onThemeToggle, currentTheme }) => {
  return (
    <header className="w-full bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm border-b border-gray-200 dark:border-slate-700 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-slate-700 to-slate-900 dark:from-slate-100 dark:to-slate-400">
              AutoAtas
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
                onClick={onThemeToggle}
                className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-700 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                aria-label="Alterar Tema"
            >
                {currentTheme === 'dark' ? <SunIcon className="w-6 h-6" /> : <MoonIcon className="w-6 h-6" />}
            </button>
            <button
                onClick={onHistoryClick}
                className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-700 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                aria-label="Histórico de Uso"
            >
                <HistoryIcon className="w-6 h-6" />
            </button>
            <button
                onClick={onSettingsClick}
                className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-gray-200 dark:hover:bg-slate-700 hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
                aria-label="Configurações"
            >
                <SettingsIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header;