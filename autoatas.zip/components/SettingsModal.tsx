
import React, { useState, useRef, useEffect } from 'react';
import { ImageIcon } from './icons/ImageIcon';
import { CloseIcon } from './icons/CloseIcon';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string, logo: string | null, apiKey: string) => void;
  initialName: string;
  initialLogo: string | null;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, onSave, initialName, initialLogo }) => {
  const [name, setName] = useState(initialName);
  const [logo, setLogo] = useState<string | null>(initialLogo);
  const [apiKey, setApiKey] = useState('');
  const logoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      const savedKey = localStorage.getItem('geminiApiKey') || '';
      setApiKey(savedKey);
    }
  }, [isOpen]);

  const handleLogoClick = () => {
    logoInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogo(reader.result as string);
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSave = () => {
    onSave(name, logo, apiKey);
  };
  
  if (!isOpen) return null;

  return (
    <div 
        className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in"
        onClick={onClose}
    >
      <div 
        className="relative bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-8 shadow-2xl w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
          aria-label="Fechar"
        >
          <CloseIcon className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-6">Configurações</h2>
        
        {/* Gemini API Key */}
        <div className="mb-6">
          <label htmlFor="apiKey" className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">
            Sua Chave de API do Gemini
          </label>
          <input
            type="password"
            id="apiKey"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="Cole sua chave de API aqui"
            className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-3 text-slate-900 dark:text-slate-200 focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 outline-none transition-all"
          />
           <p className="text-xs text-slate-500 mt-2">Sua chave é salva localmente no seu navegador e nunca é enviada para nossos servidores.</p>
        </div>

        {/* Company Name */}
        <div className="mb-6">
          <label htmlFor="companyName" className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">
            Nome da Sua Empresa (para o cabeçalho da ata)
          </label>
          <input
            type="text"
            id="companyName"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Sige Condos Inovação"
            className="w-full bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg px-4 py-3 text-slate-900 dark:text-slate-200 focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 outline-none transition-all"
          />
        </div>

        {/* Company Logo */}
        <div className="mb-8">
          <label className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">
            Logo da Sua Empresa
          </label>
          <input
              type="file"
              ref={logoInputRef}
              onChange={handleFileChange}
              accept="image/png, image/jpeg"
              className="hidden"
          />
          <button
            type="button"
            onClick={handleLogoClick}
            className="w-full h-32 bg-slate-100 dark:bg-slate-700/50 border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-lg flex items-center justify-center hover:border-cyan-400 transition-colors p-2"
            aria-label="Selecionar logo da empresa"
          >
            {logo ? (
              <img src={logo} alt="Logo da Empresa" className="max-h-full max-w-full object-contain" />
            ) : (
              <div className="flex flex-col items-center text-slate-500 dark:text-slate-400 pointer-events-none">
                  <ImageIcon className="w-8 h-8" />
                  <span className="text-sm mt-2">Selecionar Logo</span>
              </div>
            )}
          </button>
        </div>

        <button
          onClick={handleSave}
          className="interactive-button w-full bg-cyan-500 hover:bg-cyan-600 text-slate-900 font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105"
        >
          Salvar Configurações
        </button>
      </div>
    </div>
  );
};

export default SettingsModal;