import React, { useState, useRef, useEffect } from 'react';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { BoldIcon } from './icons/BoldIcon';
import { ItalicIcon } from './icons/ItalicIcon';
import { UnderlineIcon } from './icons/UnderlineIcon';
import { AlignLeftIcon } from './icons/AlignLeftIcon';
import { AlignCenterIcon } from './icons/AlignCenterIcon';
import { AlignRightIcon } from './icons/AlignRightIcon';
import { AlignJustifyIcon } from './icons/AlignJustifyIcon';
import { ListUlIcon } from './icons/ListUlIcon';
import { ListOlIcon } from './icons/ListOlIcon';
import { QuoteIcon } from './icons/QuoteIcon';

interface MinutesViewProps {
  minutes: string;
  onReset: () => void;
  condoName: string;
  condoLogo: string | null;
  companyName: string;
  companyLogo: string | null;
}

declare const jspdf: any;
declare const html2canvas: any;

const AUTOSAVE_KEY = 'autoSavedMinutesContent';

const parseMinutesToHTML = (text: string): string => {
    const trimmedText = text.trim();
    if (trimmedText === '') {
        return '<p><br></p>'; // Ensure editor starts with a valid paragraph for better command compatibility.
    }
    
    // This parser handles bold and markdown-style lists.
    const lines = trimmedText.split('\n');
    let html = '';
    let inList = false;

    const closeList = () => {
        if (inList) {
            html += '</ul>';
            inList = false;
        }
    };

    lines.forEach(line => {
        // Simple bold conversion
        let processedLine = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

        if (processedLine.trim().startsWith('- ')) {
            if (!inList) {
                html += '<ul>';
                inList = true;
            }
            html += `<li>${processedLine.trim().substring(2)}</li>`;
        } else {
            closeList();
            if (processedLine.trim() !== '') {
                // Using <p> for paragraphs for better compatibility with execCommand list formatting.
                html += `<p>${processedLine}</p>`;
            } else {
                html += '<p><br></p>'; // Represent empty lines
            }
        }
    });

    closeList();
    return html;
};


const MinutesView: React.FC<MinutesViewProps> = ({ minutes, onReset, condoName, condoLogo, companyName, companyLogo }) => {
  const [copied, setCopied] = useState(false);
  const editorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // This command standardizes the creation of new paragraphs when the user presses Enter.
    // It ensures that new lines create <p> tags, which is crucial for list formatting commands to work reliably across browsers.
    document.execCommand('defaultParagraphSeparator', false, 'p');
  }, []); // Run only once when the component mounts

  // Auto-save functionality
  useEffect(() => {
    const savedMinutes = localStorage.getItem(AUTOSAVE_KEY);
    if (savedMinutes && editorRef.current) {
      editorRef.current.innerHTML = savedMinutes;
    } else if (editorRef.current) {
        editorRef.current.innerHTML = parseMinutesToHTML(minutes);
    }

    const editor = editorRef.current;
    if (!editor) return;

    let timeoutId: number;
    const handleInput = () => {
      clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        if (editorRef.current) {
            localStorage.setItem(AUTOSAVE_KEY, editorRef.current.innerHTML);
        }
      }, 2000); // Save 2 seconds after the last input
    };

    editor.addEventListener('input', handleInput);

    return () => {
      clearTimeout(timeoutId);
      editor.removeEventListener('input', handleInput);
    };
  }, [minutes]);

  const handleCopy = () => {
    if (editorRef.current) {
      navigator.clipboard.writeText(editorRef.current.innerText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleExportPDF = () => {
    const editor = editorRef.current;
    if (!editor) return;

    // Preserve scroll position
    const savedScrollTop = editor.scrollTop;
    editor.scrollTop = 0; // Scroll to top to ensure html2canvas captures from the beginning

    const { jsPDF } = jspdf;
    const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'pt',
        format: 'a4'
    });

    const pageHeight = doc.internal.pageSize.height;
    const pageWidth = doc.internal.pageSize.width;
    const margin = 40;
    const contentWidth = pageWidth - margin * 2;
    let yPos = margin;
    
    // === PDF HEADER (Vectorial) ===
    const addHeader = (docInstance: any) => {
        yPos = margin;
        const headerHeight = 90;
        const colWidth = 155; 
        const gap = (contentWidth - (colWidth * 3)) / 2;

        const col1X = margin;
        const col2X = col1X + colWidth + gap;
        const col3X = col2X + colWidth + gap;

        docInstance.setDrawColor(100, 116, 139); // slate-500

        // Column 1: Company Info
        docInstance.rect(col1X, yPos, colWidth, headerHeight);
        if (companyLogo) {
            try {
                const imgProps = docInstance.getImageProperties(companyLogo);
                const logoAR = imgProps.width / imgProps.height;
                const logoHeight = 50;
                const logoWidth = logoHeight * logoAR;
                docInstance.addImage(companyLogo, 'PNG', col1X + (colWidth - logoWidth)/2, yPos + 10, logoWidth, logoHeight, undefined, 'FAST');
            } catch (e) { console.error("Could not add company logo to PDF:", e); }
        }
        docInstance.setFontSize(8);
        docInstance.setFont('Helvetica', 'bold');
        docInstance.text(companyName || 'Sua Empresa', col1X + colWidth / 2, yPos + 80, { align: 'center'});

        // Column 2: Condo Info & Title
        docInstance.rect(col2X, yPos, colWidth, headerHeight);
        if (condoLogo) {
            try {
                const imgProps = docInstance.getImageProperties(condoLogo);
                const logoAR = imgProps.width / imgProps.height;
                const logoHeight = 50;
                const logoWidth = logoHeight * logoAR;
                docInstance.addImage(condoLogo, 'PNG', col2X + (colWidth - logoWidth)/2, yPos + 10, logoWidth, logoHeight, undefined, 'FAST');
            } catch (e) { console.error("Could not add condo logo to PDF:", e); }
        }
        docInstance.setFontSize(8);
        docInstance.setFont('Helvetica', 'bold');
        docInstance.text("ATA DA ASSEMBLEIA GERAL", col2X + colWidth / 2, yPos + 75, { align: 'center' });
        docInstance.setFont('Helvetica', 'normal');
        docInstance.text(condoName || 'Nome do Condomínio', col2X + colWidth / 2, yPos + 83, { align: 'center' });

        // Column 3: Meeting Details
        docInstance.rect(col3X, yPos, colWidth, headerHeight);
        docInstance.setFontSize(8);
        docInstance.setFont('Helvetica', 'bold');
        docInstance.text("DATA EVENTO:", col3X + 5, yPos + 12);
        docInstance.setFont('Helvetica', 'normal');
        docInstance.text("27/03/2025 (Quinta-feira)", col3X + 5, yPos + 22);
        docInstance.line(col3X, yPos + 28, col3X + colWidth, yPos + 28);
        
        docInstance.setFont('Helvetica', 'bold');
        docInstance.text("Início:", col3X + 5, yPos + 38);
        docInstance.text("Término:", col3X + 5, yPos + 53);
        docInstance.setFont('Helvetica', 'normal');
        docInstance.text("10h30", col3X + 40, yPos + 38);
        docInstance.text("11h26", col3X + 45, yPos + 53);
        docInstance.line(col3X, yPos + 63, col3X + colWidth, yPos + 63);

        docInstance.setFont('Helvetica', 'bold');
        docInstance.text("Pág:", col3X + 5, yPos + 73);
        docInstance.setFont('Helvetica', 'normal');
        docInstance.text("1/1", col3X + 30, yPos + 73);

        yPos += headerHeight + 30;
    };

    addHeader(doc);
    
    // === PDF BODY (Rendered from HTML) ===
    const editorClone = editor.cloneNode(true) as HTMLElement;
    editorClone.style.position = 'absolute';
    editorClone.style.left = '-9999px';
    editorClone.style.width = contentWidth + 'pt';
    editorClone.style.background = 'white';
    editorClone.style.color = 'black';
    editorClone.style.fontFamily = 'Helvetica, Arial, sans-serif';
    editorClone.style.fontSize = '10pt';
    editorClone.style.lineHeight = '1.5';
    editorClone.className = ''; // Remove prose classes that might conflict
    Array.from(editorClone.getElementsByTagName('*')).forEach(el => {
        const htmlEl = el as HTMLElement;
        htmlEl.style.color = 'black';
    });

    document.body.appendChild(editorClone);

    html2canvas(editorClone, {
        scale: 2, // Higher resolution for better quality
        useCORS: true,
        logging: false,
        onclone: (clonedDoc) => {
            // Ensure lists are rendered correctly inside the canvas
            Array.from(clonedDoc.querySelectorAll('ul, ol')).forEach(list => {
                (list as HTMLElement).style.listStylePosition = 'inside';
                (list as HTMLElement).style.paddingLeft = '0';
            });
        }
    }).then(canvas => {
        document.body.removeChild(editorClone);
        const imgData = canvas.toDataURL('image/png');
        const imgProps = doc.getImageProperties(imgData);
        
        let imgWidth = contentWidth;
        let imgHeight = (imgProps.height * imgWidth) / imgProps.width;
        const availableHeight = pageHeight - yPos - margin;

        if (imgHeight > availableHeight) {
            // Content is too tall, scale it down to fit the page.
            imgWidth = (imgWidth * availableHeight) / imgHeight;
            imgHeight = availableHeight;
        }

        const xOffset = margin + (contentWidth - imgWidth) / 2;
        
        doc.addImage(imgData, 'PNG', xOffset, yPos, imgWidth, imgHeight);
        
        doc.save("ata-de-reuniao.pdf");
    }).catch(err => {
        document.body.removeChild(editorClone);
        console.error("Error exporting PDF:", err);
        alert("Ocorreu um erro ao exportar o PDF. Verifique o console para mais detalhes.");
    }).finally(() => {
        // Restore editor scroll position
        editor.scrollTop = savedScrollTop;
    });
  };
  
  const applyFormat = (command: string, value?: string) => {
    // Focus the editor before executing the command to ensure there's a valid selection.
    editorRef.current?.focus();
    document.execCommand(command, false, value);
  };

  const handleReset = () => {
    localStorage.removeItem(AUTOSAVE_KEY);
    onReset();
  };

  return (
    <div className="w-full bg-white/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 shadow-2xl backdrop-blur-sm animate-fade-in">
      <div className="flex flex-wrap gap-4 justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Ata da Reunião (Editável)</h2>
        <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="interactive-button flex items-center gap-2 bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-200 font-semibold py-2 px-4 rounded-lg transition-colors"
            >
              <ClipboardIcon className="w-5 h-5" />
              {copied ? 'Copiado!' : 'Copiar Texto'}
            </button>
            <button
              onClick={handleExportPDF}
              className="interactive-button flex items-center gap-2 bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-200 font-semibold py-2 px-4 rounded-lg transition-colors"
            >
              <DownloadIcon className="w-5 h-5" />
              Exportar PDF
            </button>
        </div>
      </div>

      <div className="bg-slate-100 dark:bg-slate-900/50 rounded-lg border border-slate-200 dark:border-slate-700 p-4 sm:p-6">
        {/* Professional Header Grid */}
        <div className="grid grid-cols-3 gap-2 items-stretch mb-6 pb-4 border-b border-slate-300 dark:border-slate-600">
            {/* Col 1: Company */}
            <div className="border border-slate-300 dark:border-slate-600 rounded-lg p-2 flex flex-col items-center justify-center text-center min-h-[10rem]">
                {companyLogo && <img src={companyLogo} alt="Logo da Empresa" className="h-16 w-auto object-contain mb-2" />}
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mt-auto">{companyName || 'Sua Empresa'}</p>
            </div>
            {/* Col 2: Condo & Title */}
            <div className="border border-slate-300 dark:border-slate-600 rounded-lg p-2 flex flex-col items-center justify-center text-center min-h-[10rem]">
                {condoLogo && <img src={condoLogo} alt="Logo do Condomínio" className="h-16 w-auto object-contain mb-2" />}
                <div className="mt-auto">
                    <p className="font-bold text-slate-800 dark:text-slate-200">ATA DA ASSEMBLEIA GERAL</p>
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">{condoName || 'Nome do Condomínio'}</p>
                </div>
            </div>
            {/* Col 3: Details Box */}
            <div className="border border-slate-300 dark:border-slate-600 rounded-lg p-2 text-xs text-slate-700 dark:text-slate-300 flex flex-col justify-between">
                <div>
                    <div className="font-bold">DATA EVENTO:</div>
                    <span>27/03/2025 (Quinta-feira)</span>
                </div>
                <hr className="border-slate-300 dark:border-slate-600 my-1"/>
                <div>
                    <div className="grid grid-cols-2">
                        <div><span className="font-bold">Início:</span> 10h30</div>
                        <div><span className="font-bold">Término:</span> 11h26</div>
                    </div>
                </div>
                 <hr className="border-slate-300 dark:border-slate-600 my-1"/>
                 <div>
                    <span className="font-bold">Pág:</span> 1/1
                </div>
            </div>
        </div>


        <div className="text-slate-700 dark:text-slate-300 bg-slate-200 dark:bg-slate-800 border border-b-0 border-slate-300 dark:border-slate-600 rounded-t-lg p-2 flex flex-wrap gap-2">
          <button onClick={() => applyFormat('bold')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Negrito"><BoldIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('italic')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Itálico"><ItalicIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('underline')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Sublinhado"><UnderlineIcon className="w-5 h-5" /></button>
          <div className="w-px bg-slate-400 dark:bg-slate-600 mx-1"></div>
          <button onClick={() => applyFormat('insertUnorderedList')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Lista de marcadores"><ListUlIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('insertOrderedList')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Lista numerada"><ListOlIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('formatBlock', 'blockquote')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Citação"><QuoteIcon className="w-5 h-5" /></button>
          <div className="w-px bg-slate-400 dark:bg-slate-600 mx-1"></div>
          <button onClick={() => applyFormat('justifyLeft')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Alinhar à esquerda"><AlignLeftIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('justifyCenter')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Centralizar"><AlignCenterIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('justifyRight')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Alinhar à direita"><AlignRightIcon className="w-5 h-5" /></button>
          <button onClick={() => applyFormat('justifyFull')} className="p-2 rounded hover:bg-slate-300 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-slate-100 transition-colors" title="Justificar"><AlignJustifyIcon className="w-5 h-5" /></button>
        </div>
        
        <div
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning={true}
          className="prose dark:prose-invert prose-slate max-w-none bg-white dark:bg-slate-800 rounded-b-lg p-4 h-[28rem] sm:h-96 overflow-y-auto border border-t-0 border-slate-300 dark:border-slate-600 focus:outline-none focus:ring-2 focus:ring-cyan-400"
        />
      </div>

      <div className="flex justify-end mt-6">
        <button
          onClick={handleReset}
          className="interactive-button bg-cyan-500 hover:bg-cyan-600 text-slate-900 font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-[0_0_20px_rgba(56,189,248,0.3)]"
        >
          Gerar Nova Ata
        </button>
      </div>
    </div>
  );
};

export default MinutesView;
