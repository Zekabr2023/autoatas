
import React, { useState, useCallback, useRef } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import { FileAudioIcon } from './icons/FileAudioIcon';
import { FileVideoIcon } from './icons/FileVideoIcon';
import { AppState } from '../types';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  onStart: () => void;
  file: File | null;
  error: string;
  disabled: boolean;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, onStart, file, error, disabled }) => {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  }, [onFileSelect]);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const triggerFileInput = () => {
    inputRef.current?.click();
  };
  
  const isVideo = file?.type.startsWith('video/');

  return (
    <div className="w-full max-w-2xl text-center bg-white/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 shadow-2xl backdrop-blur-sm">
      {!file ? (
        <div
          className={`relative flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg transition-colors duration-300 cursor-pointer ${isDragging ? 'border-cyan-400 bg-cyan-50 dark:bg-slate-700/50' : 'border-slate-300 dark:border-slate-600'}`}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onClick={triggerFileInput}
        >
          <input
            type="file"
            ref={inputRef}
            onChange={handleFileChange}
            accept="audio/*,video/*"
            className="hidden"
          />
          <div className="absolute inset-0 bg-white/50 dark:bg-slate-800/50 opacity-50"></div>
          <div className="relative z-10 flex flex-col items-center">
            <UploadIcon className="w-12 h-12 text-slate-500 mb-4" />
            <p className="text-slate-700 dark:text-slate-300 font-semibold">Arraste e solte o arquivo de áudio ou vídeo aqui</p>
            <p className="text-slate-500 dark:text-slate-400 mt-1">ou</p>
            <button
              type="button"
              className="mt-2 text-cyan-500 dark:text-cyan-400 font-semibold hover:text-cyan-600 dark:hover:text-cyan-300 transition-colors"
            >
              Selecione um arquivo
            </button>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-4">Formatos suportados: MP4, MOV, MP3, WAV, etc.</p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center">
            <div className="w-full bg-slate-100 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 rounded-lg p-4 flex items-center gap-4">
              {isVideo ? (
                 <FileVideoIcon className="w-10 h-10 text-cyan-500 dark:text-cyan-400 flex-shrink-0" />
              ) : (
                 <FileAudioIcon className="w-10 h-10 text-cyan-500 dark:text-cyan-400 flex-shrink-0" />
              )}
              <div className="text-left overflow-hidden">
                <p className="font-medium text-slate-800 dark:text-slate-200 truncate">{file.name}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400">{formatFileSize(file.size)}</p>
              </div>
            </div>
            <button 
                onClick={onStart}
                disabled={disabled}
                title={disabled ? "Preencha o nome do condomínio para começar" : "Iniciar Transcrição"}
                className="interactive-button mt-6 w-full bg-cyan-500 hover:bg-cyan-600 text-slate-900 font-bold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-[0_0_20px_rgba(56,189,248,0.3)] disabled:bg-slate-300 dark:disabled:bg-slate-600 disabled:text-slate-500 dark:disabled:text-slate-400 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none"
            >
                Transcrever e Diarizar
            </button>
        </div>
      )}
      {error && <p className="text-red-500 dark:text-red-400 mt-4">{error}</p>}
    </div>
  );
};

export default FileUpload;