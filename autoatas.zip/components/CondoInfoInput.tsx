
import React, { useRef } from 'react';
import { ImageIcon } from './icons/ImageIcon';

interface CondoInfoInputProps {
  condoName: string;
  setCondoName: (name: string) => void;
  condoLogo: string | null;
  onLogoSelect: (file: File) => void;
}

const CondoInfoInput: React.FC<CondoInfoInputProps> = ({ condoName, setCondoName, condoLogo, onLogoSelect }) => {
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleLogoClick = () => {
    logoInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onLogoSelect(e.target.files[0]);
    }
  };

  return (
    <div className="w-full max-w-2xl mb-6 flex flex-col sm:flex-row gap-4 items-start transition-opacity duration-500">
      {/* Condo Name */}
      <div className="flex-1 w-full">
        <label htmlFor="condoName" className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">
          Nome do Condomínio <span className="text-red-400">*</span>
        </label>
        <input
          type="text"
          id="condoName"
          value={condoName}
          onChange={(e) => setCondoName(e.target.value)}
          placeholder="Ex: Condomínio Edifício Barão do Rio Branco"
          className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-4 py-3 text-slate-900 dark:text-slate-200 focus:ring-2 focus:ring-cyan-400 focus:border-cyan-400 outline-none transition-all"
          required
        />
      </div>
      
      {/* Condo Logo */}
      <div className="flex-shrink-0">
         <label className="block text-sm font-medium text-slate-600 dark:text-slate-400 mb-2">
          Logo (Opcional)
        </label>
        <input
            type="file"
            ref={logoInputRef}
            onChange={handleFileChange}
            accept="image/png, image/jpeg"
            className="hidden"
        />
        <button
          type="button"
          onClick={handleLogoClick}
          className="w-32 h-[52px] bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg flex items-center justify-center hover:border-cyan-400 transition-colors p-1"
          aria-label="Selecionar logo do condomínio"
        >
          {condoLogo ? (
            <img src={condoLogo} alt="Logo do Condomínio" className="max-h-full max-w-full object-contain" />
          ) : (
            <div className="flex flex-col items-center text-slate-500 dark:text-slate-400 pointer-events-none">
                <ImageIcon className="w-6 h-6" />
                <span className="text-xs mt-1">Selecionar</span>
            </div>
          )}
        </button>
      </div>
    </div>
  );
};

export default CondoInfoInput;