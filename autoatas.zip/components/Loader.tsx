
import React from 'react';
import { AppState } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';

interface LoaderProps {
  message: string;
  stage: AppState.TRANSCRIBING | AppState.GENERATING;
}

const Loader: React.FC<LoaderProps> = ({ message, stage }) => {
  return (
    <div className="w-full max-w-2xl flex flex-col items-center justify-center text-center p-8">
      <div className="relative flex items-center justify-center w-24 h-24 mb-6">
        <div className="absolute w-full h-full rounded-full border-4 border-slate-300 dark:border-slate-700"></div>
        <div className="absolute w-full h-full rounded-full border-4 border-t-cyan-400 border-transparent animate-spin"></div>
        {stage === AppState.GENERATING ? (
            <SparklesIcon className="w-10 h-10 text-cyan-500 dark:text-cyan-400" />
        ) : (
            <svg className="w-10 h-10 text-cyan-500 dark:text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 6l12-3" />
            </svg>
        )}
      </div>
      <p className="text-lg font-semibold text-slate-800 dark:text-slate-200">{message}</p>
      <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">Por favor, não feche esta janela.</p>
    </div>
  );
};

export default Loader;