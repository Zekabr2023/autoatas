
import React, { useState, useEffect } from 'react';
import { getTokenHistory, clearTokenHistory, groupTokenUsage } from '../services/tokenService';
import { TokenUsage } from '../types';

interface HistoryViewProps {
  onBack: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ onBack }) => {
  const [history, setHistory] = useState<Record<string, TokenUsage>>({});

  useEffect(() => {
    setHistory(groupTokenUsage(getTokenHistory()));
  }, []);

  const handleClearHistory = () => {
    clearTokenHistory();
    setHistory({});
  };

  const sessionIds = Object.keys(history).sort((a, b) => {
    const dateA = new Date(history[a].timestamp).getTime();
    const dateB = new Date(history[b].timestamp).getTime();
    return dateB - dateA; // Sort descending
  });

  return (
    <div className="w-full bg-white/70 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 shadow-2xl backdrop-blur-sm animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Histórico de Uso de Tokens</h2>
        <button
          onClick={onBack}
          className="interactive-button bg-slate-200 hover:bg-slate-300 text-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-200 font-bold py-2 px-4 rounded-lg transition-colors"
        >
          &larr; Voltar
        </button>
      </div>
      
      {sessionIds.length > 0 ? (
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
            {sessionIds.map(sessionId => {
                const item = history[sessionId];
                const transUsage = item.transcriptionUsage;
                const genUsage = item.generationUsage;
                const totalTranscription = transUsage ? transUsage.promptTokenCount + transUsage.candidatesTokenCount : 0;
                const totalGeneration = genUsage ? genUsage.promptTokenCount + genUsage.candidatesTokenCount : 0;
                const totalSession = totalTranscription + totalGeneration;

                return (
                    <div key={item.id} className="bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-3">
                            <div>
                                <p className="font-semibold text-slate-800 dark:text-slate-200">Sessão</p>
                                <p className="text-xs text-slate-500 dark:text-slate-400">{new Date(item.timestamp).toLocaleString('pt-BR')}</p>
                            </div>
                            <div className="text-right">
                                <p className="font-semibold text-slate-800 dark:text-slate-200">Total: {totalSession.toLocaleString('pt-BR')} tokens</p>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                            <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded">
                                <h4 className="font-bold text-cyan-600 dark:text-cyan-400 mb-1">Transcrição</h4>
                                {transUsage ? (
                                    <>
                                        <p className="text-slate-600 dark:text-slate-400">Entrada: {transUsage.promptTokenCount.toLocaleString('pt-BR')} tokens</p>
                                        <p className="text-slate-600 dark:text-slate-400">Saída: {transUsage.candidatesTokenCount.toLocaleString('pt-BR')} tokens</p>
                                    </>
                                ) : <p className="text-slate-400 dark:text-slate-500">N/A</p>}
                            </div>
                             <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded">
                                <h4 className="font-bold text-cyan-600 dark:text-cyan-400 mb-1">Geração da Ata</h4>
                                {genUsage ? (
                                    <>
                                        <p className="text-slate-600 dark:text-slate-400">Entrada: {genUsage.promptTokenCount.toLocaleString('pt-BR')} tokens</p>
                                        <p className="text-slate-600 dark:text-slate-400">Saída: {genUsage.candidatesTokenCount.toLocaleString('pt-BR')} tokens</p>
                                    </>
                                ) : <p className="text-slate-400 dark:text-slate-500">N/A</p>}
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-slate-500 dark:text-slate-400">Nenhum registro de uso encontrado.</p>
        </div>
      )}

      {sessionIds.length > 0 && (
         <div className="flex justify-end mt-6">
            <button
                onClick={handleClearHistory}
                className="interactive-button bg-red-600/90 hover:bg-red-700/90 text-red-50 dark:bg-red-800/80 dark:hover:bg-red-700/80 dark:text-red-200 font-bold py-2 px-4 rounded-lg transition-colors"
            >
                Limpar Histórico
            </button>
        </div>
      )}
    </div>
  );
};

export default HistoryView;
