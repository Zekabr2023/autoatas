
import React, { useState, useCallback, useEffect } from 'react';
import { AppState, MinutesTemplate, TokenUsage } from './types';
import Header from './components/Header';
import FileUpload from './components/FileUpload';
import Loader from './components/Loader';
import TranscriptionView from './components/TranscriptionView';
import MinutesView from './components/MinutesView';
import { diarizeTranscript, generateMinutes } from './services/geminiService';
import { addTokenUsage } from './services/tokenService';
import CondoInfoInput from './components/CondoInfoInput';
import SettingsModal from './components/SettingsModal';
import HistoryView from './components/HistoryView';

// Constants for chunking
const CHUNK_SIZE_BYTES = 3.9 * 1024 * 1024; // ~3.9MB chunks to be safe under the API's inline data limit.

export default function App() {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [view, setView] = useState<'main' | 'history'>('main');
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [transcription, setTranscription] = useState<string>('');
  const [minutes, setMinutes] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [condoName, setCondoName] = useState<string>('');
  const [condoLogo, setCondoLogo] = useState<string | null>(null);
  const [minutesTemplate, setMinutesTemplate] = useState<MinutesTemplate>(MinutesTemplate.FORMAL);
  
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [companyName, setCompanyName] = useState<string>('');
  const [companyLogo, setCompanyLogo] = useState<string | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [theme, setTheme] = useState<'light' | 'dark'>(
    () => (localStorage.getItem('theme') as 'light' | 'dark') || 'dark'
  );

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  useEffect(() => {
    const savedCompanyName = localStorage.getItem('companyName');
    const savedCompanyLogo = localStorage.getItem('companyLogo');
    if (savedCompanyName) setCompanyName(savedCompanyName);
    if (savedCompanyLogo) setCompanyLogo(savedCompanyLogo);
  }, []);

  const handleSaveSettings = (name: string, logo: string | null, apiKey: string) => {
    setCompanyName(name);
    localStorage.setItem('companyName', name);
    if (logo) {
      setCompanyLogo(logo);
      localStorage.setItem('companyLogo', logo);
    }
    if (apiKey) {
        localStorage.setItem('geminiApiKey', apiKey);
    } else {
        localStorage.removeItem('geminiApiKey');
    }
    setIsSettingsOpen(false);
  };

  const handleFileSelect = (file: File) => {
    setMediaFile(file);
    setAppState(AppState.FILE_SELECTED);
    setError('');
  };

  const handleLogoSelect = (file: File) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      setCondoLogo(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleStartTranscription = useCallback(async () => {
    if (!mediaFile) return;

    setAppState(AppState.TRANSCRIBING);
    setError('');
    const sessionId = `session_${Date.now()}`;
    setCurrentSessionId(sessionId);
    
    try {
      setLoadingMessage('Dividindo o arquivo para processamento...');
      
      const numChunks = Math.ceil(mediaFile.size / CHUNK_SIZE_BYTES);
      const chunks: Blob[] = [];
      
      for (let i = 0; i < numChunks; i++) {
        const start = i * CHUNK_SIZE_BYTES;
        const end = Math.min(start + CHUNK_SIZE_BYTES, mediaFile.size);
        // .slice() works even if start=0 and end=size
        const chunk = mediaFile.slice(start, end, mediaFile.type); 
        chunks.push(chunk);
      }

      setLoadingMessage('Processando o arquivo... Isso pode levar alguns minutos.');
      const response = await diarizeTranscript(chunks);
      
      if (response.usageMetadata) {
        addTokenUsage({
            id: sessionId,
            timestamp: new Date().toISOString(),
            transcriptionUsage: {
                promptTokenCount: response.usageMetadata.promptTokenCount,
                candidatesTokenCount: response.usageMetadata.candidatesTokenCount,
            }
        });
      }

      setTranscription(response.text.trim());
      setAppState(AppState.TRANSCRIBED);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'Ocorreu um erro ao processar o arquivo. Tente novamente.');
      setAppState(AppState.FILE_SELECTED);
    }
  }, [mediaFile]);

  const handleStartMinuteGeneration = useCallback(async () => {
    if (!transcription || !currentSessionId) return;

    setAppState(AppState.GENERATING);
    setError('');
    try {
      setLoadingMessage('Estruturando a ata e resumindo deliberações...');
      const response = await generateMinutes(transcription, condoName, minutesTemplate);
      
      if (response.usageMetadata) {
        addTokenUsage({
            id: currentSessionId,
            timestamp: new Date().toISOString(),
            generationUsage: {
                promptTokenCount: response.usageMetadata.promptTokenCount,
                candidatesTokenCount: response.usageMetadata.candidatesTokenCount,
            }
        });
      }

      setMinutes(response.text);
      setAppState(AppState.GENERATED);
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : 'Ocorreu um erro ao gerar a ata. Tente novamente.');
      setAppState(AppState.TRANSCRIBED);
    }
  }, [transcription, condoName, minutesTemplate, currentSessionId]);

  const handleReset = () => {
    setMediaFile(null);
    setTranscription('');
    setMinutes('');
    setError('');
    setLoadingMessage('');
    setCondoName('');
    setCondoLogo(null);
    setCurrentSessionId('');
    setMinutesTemplate(MinutesTemplate.FORMAL);
    setAppState(AppState.IDLE);
  };

  const renderContent = () => {
    switch (appState) {
      case AppState.IDLE:
      case AppState.FILE_SELECTED:
        return (
          <>
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100">Comece por aqui</h2>
              <p className="mt-2 text-lg text-slate-600 dark:text-slate-400">Preencha o nome do condomínio e faça o upload do áudio.</p>
            </div>
             <CondoInfoInput
                  condoName={condoName}
                  setCondoName={setCondoName}
                  condoLogo={condoLogo}
                  onLogoSelect={handleLogoSelect}
                />
            <FileUpload
              onFileSelect={handleFileSelect}
              onStart={handleStartTranscription}
              file={mediaFile}
              error={error}
              disabled={!condoName.trim()}
            />
          </>
        );
      case AppState.TRANSCRIBING:
        return <Loader message={loadingMessage} stage={appState} />;
      case AppState.GENERATING:
        return <Loader message={loadingMessage} stage={appState} />;
      case AppState.TRANSCRIBED:
        return (
          <TranscriptionView
            transcription={transcription}
            onGenerate={handleStartMinuteGeneration}
            onReset={handleReset}
            error={error}
            minutesTemplate={minutesTemplate}
            setMinutesTemplate={setMinutesTemplate}
          />
        );
      case AppState.GENERATED:
        return (
          <MinutesView 
            minutes={minutes} 
            onReset={handleReset} 
            condoName={condoName} 
            condoLogo={condoLogo}
            companyName={companyName}
            companyLogo={companyLogo}
          />
        );
      default:
        return null;
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        onSettingsClick={() => setIsSettingsOpen(true)} 
        onHistoryClick={() => setView('history')}
        onThemeToggle={toggleTheme}
        currentTheme={theme}
       />
      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          onClose={() => setIsSettingsOpen(false)}
          onSave={handleSaveSettings}
          initialName={companyName}
          initialLogo={companyLogo}
        />
      )}
      <div className="flex-1 w-full flex flex-col items-center p-4 sm:p-6 lg:p-8">
        <main className="w-full max-w-7xl flex-1 flex flex-col items-center justify-center">
            {view === 'main' ? renderContent() : <HistoryView onBack={() => setView('main')} />}
        </main>
        <footer className="w-full text-center p-4 mt-8 text-slate-600 dark:text-slate-400 text-sm">
            <p>Potencializado por IA para simplificar a vida em condomínio.</p>
        </footer>
      </div>
    </div>
  );
}
